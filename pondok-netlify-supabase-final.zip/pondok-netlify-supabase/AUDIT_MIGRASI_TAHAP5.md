# Audit migrasi tahap 5 — Pondok / Netlify + Supabase

Tanggal: 26 November 2026

## Perubahan

1. Menambahkan `scripts/test-pg-adapter.cjs`, pengujian mandiri berbasis Node.js built-in test assertions dan TypeScript transpile API.
2. Mengubah `npm run test:pg-adapter` agar menjalankan pengujian adapter tanpa membutuhkan `tsx` runtime. Pengujian ini tetap membutuhkan paket `typescript` yang sudah menjadi devDependency proyek.
3. Pengujian mencakup konversi placeholder `?`, identifier backtick, YEAR/MONTH, literal dan komentar, ekspresi bersarang, query/execute, serta alur commit dan pelepasan koneksi transaksi.

## Hasil yang dapat dijalankan pada lingkungan ini

- `npm run preflight:static`: 7/7 lulus.
- `node scripts/test-pg-adapter.cjs`: 6/6 lulus.
- `npm install --ignore-scripts --no-audit --no-fund --prefer-offline`: timeout pada akses registry; tidak ada `node_modules` yang tersedia.

## Batasan validasi

- Tes adapter memakai Pool/Client tiruan (mock), bukan PostgreSQL sungguhan.
- Build Vite, typecheck lengkap, unit test aplikasi, bundling Netlify, dan smoke test database belum dapat dijalankan tanpa dependensi.
- Schema belum dieksekusi pada project Supabase pengguna.
- Uji login iframe pada browser Android belum dilakukan.

**Status: belum siap deploy operasional.** Paket ini adalah kelanjutan persiapan; jangan menjalankan transaksi riil sampai validasi penuh selesai.
