# Status migrasi Pondok → Netlify + Supabase

Pembaruan: 27 November 2026

## Status yang sudah diverifikasi langsung

| Komponen | Status | Bukti |
|---|---|---|
| Project Supabase `pondok-alhidayah` | Aktif | Status `ACTIVE_HEALTHY`, PostgreSQL 17 |
| Database schema | Diterapkan | 20 tabel `public` berhasil dibuat |
| Row Level Security | Aktif | RLS aktif pada 20/20 tabel; tidak ada policy publik |
| Index foreign key | Diterapkan | Migration `index_foreign_keys` berhasil |
| Periode pembayaran iuran | Diperbaiki | Kolom `periode_bulan` dan `periode_tahun` sudah ditambahkan dan diverifikasi |
| Data aplikasi | Kosong | Belum ada data pengguna/santri/transaksi yang diimpor atau dibuat |
| Kode aktivasi Super Admin pertama | Ditambahkan ke paket | `INITIAL_SETUP_SECRET` wajib di Netlify dan diminta pada halaman setup |
| Preflight statis | Lulus | 9/9 pemeriksaan |
| Adapter PostgreSQL terisolasi | Lulus | 6/6 tes mock |

## Yang belum berhasil diverifikasi

- `npm install` berjalan timeout pada lingkungan kerja; dependency proyek belum tersedia untuk build penuh.
- Build Vite/Netlify Functions, typecheck lengkap, unit test TypeScript, dan E2E belum dijalankan.
- Repo GitHub `maghfuri14/pondok` terhubung dengan permission baca (`pull: true`, `push: false`). File migrasi belum masuk ke branch `main`; belum ada workflow GitHub Actions dan belum ada run CI.
- Belum ada situs Netlify yang dibuat/deploy atau URL HTTPS.
- Belum ada `DATABASE_URL`, `SESSION_SECRET`, dan `INITIAL_SETUP_SECRET` yang dimasukkan ke environment Netlify. Nilai rahasia tersebut tidak diminta/dikirim melalui chat.
- Belum ada smoke test koneksi backend melalui Netlify, autentikasi dalam iframe Blogspot, atau transaksi database nyata melalui API.

## Keamanan database

RLS sengaja diaktifkan pada semua tabel tanpa policy publik. Artinya akses melalui Data API publik tidak dibuka. Backend Netlify harus mengakses PostgreSQL dari server dengan kredensial database yang disimpan sebagai environment variable rahasia. Jangan menambahkan policy `anon`/`authenticated` yang memberi akses luas hanya untuk menghilangkan INFO advisor.

Endpoint setup awal kini membutuhkan `INITIAL_SETUP_SECRET` di produksi. Buat kode acak minimal 32 karakter, simpan di Netlify Environment Variables, lalu masukkan sekali pada halaman Buat Akun Super Admin. Jangan pernah meletakkan kode itu di `VITE_*`, Blogger, repo, atau chat.

## Kesimpulan

Database Supabase sudah terpasang dan struktur utamanya telah diperbaiki, tetapi aplikasi **belum siap deploy/operasional**. Penghalang berikutnya adalah akses tulis untuk memasukkan paket ke GitHub (atau unggah paket secara manual), build/CI yang benar-benar hijau, pembuatan site Netlify, pengisian environment variables rahasia, dan smoke test.
