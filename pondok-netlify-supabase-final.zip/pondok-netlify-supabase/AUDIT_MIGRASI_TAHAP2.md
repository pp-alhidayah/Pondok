# Audit dan perubahan migrasi tahap 2

Tanggal: 26 November 2026

## Perubahan pada salinan kerja

1. **Autentikasi iframe**
   - Login menghasilkan token acak 256-bit.
   - Frontend menyimpan token pada `sessionStorage` dalam iframe dan mengirim `Authorization: Bearer ...`.
   - Backend menyimpan HMAC-SHA256 token, bukan token mentah, di tabel `sessions`.
   - CSRF tetap diwajibkan untuk mutation, termasuk logout.
   - Setup Super Admin pertama memakai advisory transaction lock agar dua permintaan bersamaan tidak membuat dua akun pertama.

2. **PostgreSQL adapter**
   - Penerjemah SQL mengubah placeholder `?`, identifier backtick, `YEAR()` dan `MONTH()`.
   - Penerjemah placeholder mengabaikan tanda tanya di string literal dan komentar SQL.
   - Counter kuitansi memakai `INSERT ... ON CONFLICT ... RETURNING`.
   - Pembacaan JSONB pada modul keringanan disesuaikan karena `pg` mengembalikan objek JSON secara langsung.

3. **Netlify**
   - Function Express tersedia pada `netlify/functions/api.ts`.
   - `netlify.toml` menetapkan mode API produksi, routing `/api/*`, health check, SPA fallback, dan CSP iframe Blogspot.
   - `.npmrc` mengaktifkan legacy peer dependency resolution untuk instalasi npm.

## Pemeriksaan yang berhasil

- Pemeriksaan sintaks TypeScript seluruh `src`, `server`, dan `netlify`: 0 diagnostic.
- Parsing `netlify.toml`: berhasil; tiga redirect terdeteksi.
- Pemeriksaan terisolasi adapter SQL: 3/3 kasus lulus.
- Audit awal insert SQL: 20 tabel schema terdeteksi; tidak ditemukan mismatch kolom insert statis (satu insert dinamis tidak dapat diverifikasi oleh pemeriksaan sederhana).

## Belum berhasil / belum dilakukan

- `npm install` timeout saat mengakses registry; dependencies belum terpasang.
- Build Vite dan pemeriksaan tipe penuh belum bisa dilakukan.
- SQL belum dieksekusi di Supabase PostgreSQL.
- Belum ada integration test terhadap transaksi pembayaran, kas, pembatalan, dan kuitansi di PostgreSQL nyata.
- Belum ada tes deploy Netlify atau tes login dari iframe Blogspot di Android.

**Status: belum siap deploy operasional.** Jangan jalankan schema di Supabase dulu dan jangan masukkan kredensial ke chat. Tahap berikutnya adalah menjalankan build di environment yang dapat mengakses npm, lalu menguji schema dan alur transaksi pada database staging.
