# Panduan Deploy Produksi — Sistem Informasi Pondok Al Hidayah

Arsitektur produksi: **SPA Vite/React** (folder `dist/`) → **Netlify Functions** (Express adapter) → **Supabase PostgreSQL**. Tidak ada localStorage sebagai sumber data; localStorage hanya cache baca yang disinkronkan dari API.

## 1. Prasyarat

- Node.js 20+
- Akun Netlify dan project Supabase PostgreSQL
- Node.js 20+ untuk build lokal (Netlify juga dapat melakukan build)
- URL HTTPS Netlify untuk frontend

## 2. Konfigurasi environment

Salin template lalu isi nilai produksi:

```bash
cp .env.example .env
cp env.production.example .env.production
```

Contoh `.env` (server):

```ini
DATABASE_URL=postgresql://USER:PASSWORD@POOLER-HOST:6543/postgres?sslmode=require
NODE_ENV=production
CORS_ORIGINS=https://NAMA-SITUS.netlify.app
SESSION_SECRET=<64-96 karakter acak>
INITIAL_SETUP_SECRET=<kode aktivasi acak minimal 32 karakter>
SESSION_TTL_HOURS=12
PG_POOL_MAX=5
```

`DATABASE_URL`, `SESSION_SECRET`, dan `INITIAL_SETUP_SECRET` harus dibuat sebagai Environment Variables Netlify server-side, bukan variabel `VITE_*`. Jangan mengirim nilainya melalui chat. Kode aktivasi awal dipakai sekali saat membuat Super Admin pertama; setelah akun dibuat, endpoint setup otomatis menolak pembuatan akun tambahan.

Buat secret acak:

```bash
node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"
# Jalankan perintah terpisah untuk kode aktivasi awal
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

Contoh `.env.production` (dipakai Vite saat `npm run build`):

`netlify.toml` sudah menetapkan `VITE_API_MODE=api`. API dipanggil melalui path relatif `/api`, sehingga `VITE_API_URL` dibiarkan kosong.

> `VITE_*` tertanam di bundle saat build. Ubah `.env.production` **sebelum** build, lalu build ulang.
>
> **Jangan** mengisi `VITE_API_URL` dengan `https://.../api`. Setiap `apiRequest` sudah
> memakai path `/api/...`, jadi akhirnya akan menjadi `/api/api/...`. Isi origin saja
> atau kosongkan untuk same-origin.

## 3. Database

**Project saat ini `pondok-alhidayah` sudah memiliki schema 20 tabel.** Tiga migration telah diterapkan: `pondok_initial_schema`, `index_foreign_keys`, dan `add_iuran_payment_period_columns`. Jangan membuat project baru atau mengulang langkah manual tanpa kebutuhan.

Untuk project Supabase baru yang masih kosong:

1. Buka Supabase → SQL Editor.
2. Salin isi `schema-supabase.sql` dari paket migrasi. Jalankan hanya setelah build dan schema mendapat validasi akhir.
3. Jalankan `scripts/verify-supabase.sql`; hasil yang diharapkan adalah 20 tabel dan 20 tabel dengan RLS aktif, tanpa data demo.
4. Di Netlify, isi `DATABASE_URL` menggunakan connection string PostgreSQL dari Supabase (untuk Functions, utamakan connection pooler).

DDL target produksi ada di `schema-supabase.sql`; `MIGRASI_DB.md` tetap menjadi dokumen historis spesifikasi MySQL dan belum boleh dieksekusi di Supabase.

Data produksi dimulai kosong. Super Admin dibuat lewat `POST /api/auth/setup` (tersedia hanya saat tabel `users` kosong).

## 4. Build & jalankan

Sebelum build, jalankan `npm run preflight:static` untuk pemeriksaan statis. Pemeriksaan ini bukan pengganti build, typecheck, unit test, atau integration test PostgreSQL.

Netlify menjalankan `npm install` dan `npm run build`, lalu menerbitkan folder `dist` dan Functions dari `netlify/functions`. Sebelum deploy, jalankan pemeriksaan build/test di staging; paket saat ini belum lulus validasi tersebut.

## 5. Netlify routing dan iframe Blogspot

`netlify.toml` sudah mengarahkan `/api/*` ke Netlify Function. Header CSP hanya mengizinkan halaman Blogspot Al-Hidayah sebagai parent iframe.


Service worker hanya mendaftar saat `import.meta.env.PROD` — pastikan aplikasi dilayani via HTTPS.

## 6. Checklist keamanan

- [ ] Semua perubahan sudah di-commit & di-push ke `origin` (commit terakhir sudah bersih)
- [ ] `SESSION_SECRET` diganti dari nilai development (minimal 32 byte acak)
- [ ] `VITE_API_URL` tidak mengandung `/api` dan tidak pointing ke `localhost`
- [ ] `NODE_ENV=production` (error detail tidak bocor; sesi bearer hanya disimpan di sessionStorage iframe)
- [ ] `CORS_ORIGINS` berisi URL Netlify aplikasi yang benar (bukan `*`)
- [ ] DATABASE_URL hanya disimpan pada environment Netlify server-side
- [ ] User DB bukan `root`, password kuat, hak hanya untuk DB aplikasi
- [ ] HTTPS aktif di frontend & API
- [ ] Tidak ada akun demo produksi (setup Super Admin pertama)
- [ ] Backup disimpan terenkripsi & tidak mengandung password plaintext (API `/api/backup` menghilangkan `password_hash`)
- [ ] Log audit (`activity_log`) dipantau; skrip backup otomatis disiapkan
- [ ] Header CSRF `x-csrf-token` wajib untuk semua mutation

## 7. Backup & restore

- **Download**: menu Pengaturan → Backup (memanggil `GET /api/backup`).
- **Restore**: menu Pengaturan → Restore (memanggil `POST /api/restore`).
- File backup produksi berisi **nama tabel DB**, bukan key `al_hidayah_*`.
- Backup format localStorage lama **ditolak** di mode API — jangan dipakai untuk produksi.
- Simpan backup di lokasi terpisah + enkripsi; uji restore secara berkala di staging.

## 8. Verifikasi pasca-deploy

```bash
curl https://NAMA-SITUS.netlify.app/health
npm run lint && npm run lint:server && npm test
npx tsx --test server/tests/*.test.ts
npm run test:e2e
# Smoke terhadap DB produksi/staging:
npm run test:smoke
```

Smoke test mencakup: pembayaran (transaksi + kas + matriks + kuitansi), konkurensi nomor kuitansi, rollback pembatalan, penolakan 403 untuk role `pemilik`, dan siklus keringanan Super Admin (potong → cabut → tagihan pulih).

## 9. Catatan operasional

- Build menyisakan warning chunk >500 kB (~2,1 MB) — sudah dikenal, tidak memblokir.
- `xlsx` berasal dari tarball resmi SheetJS 0.20.3; jangan diturunkan ke `0.18.x` (advisory high).
- Perubahan schema PostgreSQL **wajib** dilakukan di `schema-supabase.sql` dan diuji di project Supabase staging terlebih dahulu.
- Semua aturan bisnis penting ada di `PERBAIKAN_LOGIKA.md` dan `AGENTS.md`.
- Jika memakai domain berbeda untuk API, set `CORS_ORIGINS` dan `VITE_API_URL` sesuai, lalu build ulang frontend.
