const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const ts = require('typescript');

const sourcePath = path.join(__dirname, '..', 'server', 'src', 'db.ts');
const source = fs.readFileSync(sourcePath, 'utf8');
const compiled = ts.transpileModule(source, {
  compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022, esModuleInterop: true },
}).outputText;

const calls = [];
let released = false;
let poolConfig;
class FakePool {
  constructor(config) { poolConfig = config; }
  async query(sql, params) { calls.push({ sql, params, connection: 'pool' }); return { rows: [{ ok: 1 }], rowCount: 1 }; }
  async connect() {
    return {
      async query(sql, params) { calls.push({ sql, params, connection: 'client' }); return { rows: [{ ok: 1 }], rowCount: 1 }; },
      release() { released = true; },
    };
  }
}
const loadedModule = { exports: {} };
const sandboxRequire = (id) => {
  if (id === 'pg') return { Pool: FakePool };
  if (id === './config') return { isProduction: false };
  throw new Error(`Unexpected module import: ${id}`);
};
vm.runInNewContext(compiled, {
  require: sandboxRequire,
  module: loadedModule,
  exports: loadedModule.exports,
  process: { env: {} },
  console,
  Buffer,
  setTimeout,
  clearTimeout,
});
const db = loadedModule.exports;

const tests = [];
function test(name, fn) { tests.push([name, fn]); }
test('converts placeholders and backtick identifiers', () => {
  assert.equal(db.toPostgresSql('SELECT * FROM `santri` WHERE id = ? AND nama LIKE ?'), 'SELECT * FROM "santri" WHERE id = $1 AND nama LIKE $2');
});
test('converts YEAR and MONTH functions', () => {
  assert.equal(db.toPostgresSql('SELECT YEAR(tanggal), MONTH(tanggal) FROM buku_kas WHERE YEAR(tanggal) = ?'), 'SELECT EXTRACT(YEAR FROM tanggal), EXTRACT(MONTH FROM tanggal) FROM buku_kas WHERE EXTRACT(YEAR FROM tanggal) = $1');
});
test('does not rewrite placeholders or date functions in literals and comments', () => {
  assert.equal(db.toPostgresSql("SELECT '?' AS literal, 'YEAR(tanggal)' AS label, col = ? -- ignore ? MONTH(tanggal)\nFROM t WHERE id = ?"), "SELECT '?' AS literal, 'YEAR(tanggal)' AS label, col = $1 -- ignore ? MONTH(tanggal)\nFROM t WHERE id = $2");
});
test('handles nested expressions and preserves row locks', () => {
  assert.equal(db.toPostgresSql('SELECT YEAR(COALESCE(tanggal, NOW())) FROM t WHERE id = ? FOR UPDATE'), 'SELECT EXTRACT(YEAR FROM COALESCE(tanggal, NOW())) FROM t WHERE id = $1 FOR UPDATE');
});
test('query and execute preserve rows and affected-row counts', async () => {
  const rows = await db.query('SELECT * FROM `users` WHERE id = ?', ['u1']);
  assert.equal(rows[0].ok, 1);
  const result = await db.execute('UPDATE users SET nama = ? WHERE id = ?', ['Nama', 'u1']);
  assert.equal(result.affectedRows, 1);
  assert.equal(calls.at(-1).sql, 'UPDATE users SET nama = $1 WHERE id = $2');
});
test('transaction commits and always releases its client', async () => {
  const result = await db.withTransaction(async (conn) => {
    const [rows] = await conn.query('SELECT * FROM `users` WHERE id = ?', ['u1']);
    assert.equal(rows[0].ok, 1);
    await conn.execute('UPDATE users SET nama = ? WHERE id = ?', ['Nama', 'u1']);
    return 'committed';
  });
  assert.equal(result, 'committed');
  assert.equal(calls.at(-1).sql, 'COMMIT');
  assert.equal(released, true);
});

(async () => {
  let failed = 0;
  for (const [name, fn] of tests) {
    try { await fn(); console.log(`PASS | ${name}`); }
    catch (error) { failed++; console.error(`FAIL | ${name}\n${error.stack || error}`); }
  }
  console.log(`\nPostgreSQL adapter isolated tests: ${tests.length - failed}/${tests.length} passed.`);
  if (failed) process.exitCode = 1;
})();
