const { readFile, readdir } = require('node:fs/promises');
const path = require('node:path');
const ts = require('typescript');

async function main() {
const roots = ['src', 'server/src', 'netlify'];
const files = [];
async function walk(dir) {
  for (const entry of await readdir(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) await walk(full);
    else if (/\.tsx?$/.test(entry.name)) files.push(full);
  }
}
for (const root of roots) await walk(root);
let syntaxErrors = 0;
for (const file of files) {
  const source = await readFile(file, 'utf8');
  const kind = file.endsWith('.tsx') ? ts.ScriptKind.TSX : ts.ScriptKind.TS;
  const parsed = ts.createSourceFile(file, source, ts.ScriptTarget.Latest, true, kind);
  for (const diagnostic of parsed.parseDiagnostics) {
    syntaxErrors += 1;
    const message = ts.flattenDiagnosticMessageText(diagnostic.messageText, '\n');
    console.error(`${file}: ${message}`);
  }
}

const schema = await readFile('schema-supabase.sql', 'utf8');
const tables = [...schema.matchAll(/CREATE TABLE IF NOT EXISTS\s+(\w+)/gi)].map((m) => m[1]);
const rls = [...schema.matchAll(/ALTER TABLE\s+(\w+)\s+ENABLE ROW LEVEL SECURITY/gi)].map((m) => m[1]);
const duplicateTables = tables.length - new Set(tables).size;
const missingRls = tables.filter((table) => !rls.includes(table));
const netlify = await readFile('netlify.toml', 'utf8');
const functionEntry = await readFile('netlify/functions/api.ts', 'utf8');
const packageJson = JSON.parse(await readFile('package.json', 'utf8'));
const authConfig = await readFile('server/src/config.ts', 'utf8');
const authRoutes = await readFile('server/src/routes/authRoutes.ts', 'utf8');
const setupCard = await readFile('src/features/auth/InitialSetupCard.tsx', 'utf8');
const apiClient = await readFile('src/lib/apiClient.ts', 'utf8');
const checks = [
  ['TypeScript syntax', syntaxErrors === 0, `${files.length} file; ${syntaxErrors} error`],
  ['Schema tables', tables.length === 20 && duplicateTables === 0, `${tables.length} table; ${duplicateTables} duplicate`],
  ['RLS coverage', missingRls.length === 0 && rls.length === tables.length, `${rls.length}/${tables.length}; missing: ${missingRls.join(', ') || 'none'}`],
  ['Netlify API redirect', netlify.includes('to = "/.netlify/functions/api/api/:splat"'), 'redirect /api/* → function'],
  ['Netlify function adapter', functionEntry.includes('serverless(app') && functionEntry.includes('basePath'), 'serverless-http adapter found'],
  ['Production API mode', netlify.includes('VITE_API_MODE = "api"'), 'VITE_API_MODE=api'],
  ['PostgreSQL driver', Boolean(packageJson.dependencies?.pg), 'pg dependency present'],
  ['Iuran period columns', schema.includes('periode_bulan') && schema.includes('periode_tahun'), 'periode_bulan and periode_tahun found'],
  ['Protected first-admin setup', authConfig.includes('INITIAL_SETUP_SECRET') && authConfig.includes('initialSetupSecret.length < 32') && authRoutes.includes('matchesSetupSecret') && setupCard.includes('setup-secret') && apiClient.includes('setup_secret: setupSecret'), 'production setup requires server-side activation secret'],
];
let failed = 0;
for (const [name, ok, detail] of checks) {
  console.log(`${ok ? 'PASS' : 'FAIL'} | ${name} | ${detail}`);
  if (!ok) failed += 1;
}
console.log(`\nStatic preflight: ${checks.length - failed}/${checks.length} checks passed.`);
if (failed) process.exitCode = 1;

}
main().catch((error) => { console.error(error); process.exitCode = 1; });
