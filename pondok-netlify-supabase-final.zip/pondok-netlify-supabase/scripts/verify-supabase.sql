-- Run AFTER schema-supabase.sql in Supabase SQL Editor.
-- Expected: 20 application tables, all with RLS enabled, and no application rows.
SELECT
  COUNT(*) FILTER (WHERE c.relkind = 'r') AS table_count,
  COUNT(*) FILTER (WHERE c.relkind = 'r' AND c.relrowsecurity) AS rls_enabled_count
FROM pg_class c
JOIN pg_namespace n ON n.oid = c.relnamespace
WHERE n.nspname = 'public'
  AND c.relname IN (
    'users','sessions','santri','santri_periode_nonaktif','syahriyah_bulan',
    'keringanan_syahriyah','transaksi_syahriyah','kilatan_bulan','transaksi_kilatan',
    'kategori_kas','buku_kas','pendaftaran','master_iuran','iuran_pembayaran',
    'iuran_tambahan','kuitansi_counter','pengaturan','arsip_tarif','print_log','activity_log'
  );

-- Check that the two critical unique constraints exist.
SELECT conrelid::regclass AS table_name, conname, pg_get_constraintdef(oid) AS definition
FROM pg_constraint
WHERE conname IN ('uq_syahriyah','uq_kilatan')
ORDER BY conrelid::regclass::text;

-- Required period columns used by iuran payment routes.
SELECT column_name, data_type
FROM information_schema.columns
WHERE table_schema = 'public'
  AND table_name = 'iuran_pembayaran'
  AND column_name IN ('periode_bulan','periode_tahun')
ORDER BY column_name;

-- New demo environment should have no records yet.
SELECT 'users' AS table_name, COUNT(*) AS row_count FROM public.users
UNION ALL SELECT 'santri', COUNT(*) FROM public.santri
UNION ALL SELECT 'transaksi_syahriyah', COUNT(*) FROM public.transaksi_syahriyah
UNION ALL SELECT 'transaksi_kilatan', COUNT(*) FROM public.transaksi_kilatan
UNION ALL SELECT 'buku_kas', COUNT(*) FROM public.buku_kas;
