-- SIPAH / Pondok: PostgreSQL schema for Supabase
-- Generated from the source repository MIGRASI_DB.md DDL.
-- Production starts empty; this schema intentionally creates no demo rows.
-- Review before running in Supabase SQL Editor.

CREATE TABLE IF NOT EXISTS users (
  id            VARCHAR(36) PRIMARY KEY,
  nama          VARCHAR(120) NOT NULL,
  username      VARCHAR(80)  NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role          TEXT CHECK (role IN ('super_admin','admin','pemilik')) NOT NULL,
  status        TEXT CHECK (status IN ('Aktif','Nonaktif')) NOT NULL DEFAULT 'Aktif',
  created_at    TIMESTAMP WITHOUT TIME ZONE NOT NULL,
  updated_at    TIMESTAMP WITHOUT TIME ZONE NOT NULL
);

CREATE TABLE IF NOT EXISTS sessions (
  id         VARCHAR(64) PRIMARY KEY,
  user_id    VARCHAR(36) NOT NULL,
  csrf_token VARCHAR(64) NOT NULL,
  expires_at TIMESTAMP WITHOUT TIME ZONE NOT NULL,
  created_at TIMESTAMP WITHOUT TIME ZONE NOT NULL,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS santri (
  id             VARCHAR(36) PRIMARY KEY,
  nis            VARCHAR(40) NOT NULL UNIQUE,
  nama           VARCHAR(150) NOT NULL,
  nama_wali      VARCHAR(150) NOT NULL DEFAULT '',
  no_hp_santri   VARCHAR(30)  NOT NULL DEFAULT '',
  no_hp_wali     VARCHAR(30)  NOT NULL DEFAULT '',
  kategori       TEXT CHECK (kategori IN ('Mukim','Nduduk','Kilatan')) NOT NULL,
  status         TEXT CHECK (status IN ('Aktif','Tidak Aktif')) NOT NULL DEFAULT 'Aktif',
  tanggal_masuk  DATE NOT NULL,
  tanggal_keluar DATE NULL,
  foto           TEXT NULL,
  catatan        TEXT NULL,
  created_at     TIMESTAMP WITHOUT TIME ZONE NOT NULL,
  updated_at     TIMESTAMP WITHOUT TIME ZONE NOT NULL,
  created_by     VARCHAR(36) NULL,
  updated_by     VARCHAR(36) NULL,
  FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL,
  FOREIGN KEY (updated_by) REFERENCES users(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS santri_periode_nonaktif (
  id        VARCHAR(36) PRIMARY KEY,
  santri_id VARCHAR(36) NOT NULL,
  mulai     DATE NOT NULL,
  sampai    DATE NULL,
  FOREIGN KEY (santri_id) REFERENCES santri(id) ON DELETE CASCADE,
  CONSTRAINT chk_periode CHECK (sampai IS NULL OR sampai >= mulai)
);

CREATE TABLE IF NOT EXISTS syahriyah_bulan (
  id              VARCHAR(36) PRIMARY KEY,
  santri_id       VARCHAR(36) NOT NULL,
  tahun           SMALLINT NOT NULL,
  bulan           SMALLINT NOT NULL,
  nominal_tagihan BIGINT NOT NULL DEFAULT 0,
  total_dibayar   BIGINT NOT NULL DEFAULT 0,
  status          TEXT CHECK (status IN ('Lunas','Sebagian','Belum')) NOT NULL DEFAULT 'Belum',
  keringanan      BOOLEAN NOT NULL DEFAULT FALSE,
  FOREIGN KEY (santri_id) REFERENCES santri(id) ON DELETE CASCADE,
  CONSTRAINT uq_syahriyah UNIQUE (santri_id, tahun, bulan),
  CONSTRAINT chk_bulan CHECK (bulan BETWEEN 1 AND 12)
);

CREATE TABLE IF NOT EXISTS keringanan_syahriyah (
  id                 VARCHAR(36) PRIMARY KEY,
  santri_id          VARCHAR(36) NOT NULL,
  tahun              SMALLINT NOT NULL,
  bulan_mulai        SMALLINT NOT NULL,
  bulan_selesai      SMALLINT NOT NULL,
  jenis              TEXT CHECK (jenis IN ('kustom','setengah','penuh')) NOT NULL DEFAULT 'kustom',
  nominal_per_bulan  BIGINT NOT NULL DEFAULT 0,
  keterangan         TEXT NULL,
  snapshot           JSONB NULL,
  created_at         TIMESTAMP WITHOUT TIME ZONE NOT NULL,
  created_by         VARCHAR(36) NULL,
  FOREIGN KEY (santri_id) REFERENCES santri(id) ON DELETE CASCADE,
  FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL,
  CONSTRAINT chk_keringanan_bulan CHECK (
    bulan_mulai BETWEEN 1 AND 12 AND bulan_selesai BETWEEN 1 AND 12 AND bulan_selesai >= bulan_mulai
  )
);

CREATE TABLE IF NOT EXISTS transaksi_syahriyah (
  id               VARCHAR(36) PRIMARY KEY,
  nomor_kuitansi   VARCHAR(30) NOT NULL UNIQUE,
  kas_id           VARCHAR(36) NULL,
  santri_id        VARCHAR(36) NOT NULL,
  santri_nama      VARCHAR(150) NOT NULL,
  santri_nis       VARCHAR(40)  NOT NULL,
  tanggal_bayar    DATE NOT NULL,
  metode           TEXT CHECK (metode IN ('Tunai','Transfer','Lainnya')) NOT NULL DEFAULT 'Tunai',
  keterangan       TEXT NULL,
  iuran_tambahan   JSONB NULL,
  items            JSONB NOT NULL,
  total_pembayaran BIGINT NOT NULL,
  created_at       TIMESTAMP WITHOUT TIME ZONE NOT NULL,
  created_by       VARCHAR(36) NULL,
  FOREIGN KEY (santri_id) REFERENCES santri(id) ON DELETE RESTRICT,
  FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS kilatan_bulan (
  id              VARCHAR(36) PRIMARY KEY,
  santri_id       VARCHAR(36) NOT NULL,
  tahun           SMALLINT NOT NULL,
  event           TEXT CHECK (event IN ('Jumadil Ula','Maulid','Romadhon','Dzulhijjah')) NOT NULL,
  nominal_tagihan BIGINT NOT NULL DEFAULT 0,
  total_dibayar   BIGINT NOT NULL DEFAULT 0,
  status          TEXT CHECK (status IN ('Lunas','Sebagian','Belum')) NOT NULL DEFAULT 'Belum',
  FOREIGN KEY (santri_id) REFERENCES santri(id) ON DELETE CASCADE,
  CONSTRAINT uq_kilatan UNIQUE (santri_id, tahun, event)
);

CREATE TABLE IF NOT EXISTS transaksi_kilatan (
  id               VARCHAR(36) PRIMARY KEY,
  nomor_kuitansi   VARCHAR(30) NOT NULL UNIQUE,
  kas_id           VARCHAR(36) NULL,
  santri_id        VARCHAR(36) NOT NULL,
  santri_nama      VARCHAR(150) NOT NULL,
  santri_nis       VARCHAR(40)  NOT NULL,
  tanggal_bayar    DATE NOT NULL,
  metode           TEXT CHECK (metode IN ('Tunai','Transfer','Lainnya')) NOT NULL DEFAULT 'Tunai',
  keterangan       TEXT NULL,
  iuran_tambahan   JSONB NULL,
  items            JSONB NOT NULL,
  total_pembayaran BIGINT NOT NULL,
  created_at       TIMESTAMP WITHOUT TIME ZONE NOT NULL,
  created_by       VARCHAR(36) NULL,
  FOREIGN KEY (santri_id) REFERENCES santri(id) ON DELETE RESTRICT,
  FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS kategori_kas (
  jenis TEXT CHECK (jenis IN ('pemasukan','pengeluaran')) NOT NULL,
  nama  VARCHAR(100) NOT NULL,
  PRIMARY KEY (jenis, nama)
);

CREATE TABLE IF NOT EXISTS buku_kas (
  id            VARCHAR(36) PRIMARY KEY,
  tanggal       DATE NOT NULL,
  jenis         TEXT CHECK (jenis IN ('Pemasukan','Pengeluaran')) NOT NULL,
  kategori_nama VARCHAR(100) NOT NULL,
  nominal       BIGINT NOT NULL,
  keterangan    TEXT NULL,
  sumber_modul  TEXT CHECK (sumber_modul IN ('syahriyah','kilatan','iuran')) NULL,
  sumber_ref_id VARCHAR(36) NULL,
  created_at    TIMESTAMP WITHOUT TIME ZONE NOT NULL,
  created_by    VARCHAR(36) NULL,
  FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL,
  CONSTRAINT uq_kas_sumber UNIQUE (sumber_modul, sumber_ref_id)
);

CREATE TABLE IF NOT EXISTS pendaftaran (
  id                  VARCHAR(36) PRIMARY KEY,
  nama_calon          VARCHAR(150) NOT NULL,
  nama_wali           VARCHAR(150) NOT NULL,
  no_hp_santri        VARCHAR(30)  NOT NULL,
  no_hp_wali          VARCHAR(30)  NOT NULL,
  kategori            TEXT CHECK (kategori IN ('Mukim','Nduduk','Kilatan')) NOT NULL,
  tanggal_pendaftaran DATE NOT NULL,
  status              TEXT CHECK (status IN ('Baru','Diterima','Ditolak','Menjadi Santri')) NOT NULL DEFAULT 'Baru',
  nis_generated       VARCHAR(40) NULL,
  santri_id           VARCHAR(36) NULL,
  catatan             TEXT NULL,
  created_at          TIMESTAMP WITHOUT TIME ZONE NOT NULL,
  created_by          VARCHAR(36) NULL,
  FOREIGN KEY (santri_id) REFERENCES santri(id) ON DELETE SET NULL,
  FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS master_iuran (
  id              VARCHAR(36) PRIMARY KEY,
  nama            VARCHAR(150) NOT NULL UNIQUE,
  nominal_default BIGINT NOT NULL,
  jenis_periode   TEXT CHECK (jenis_periode IN ('sekali','bulanan','tahunan')) NOT NULL,
  status          TEXT CHECK (status IN ('Aktif','Nonaktif')) NOT NULL DEFAULT 'Aktif',
  keterangan      TEXT NULL,
  created_at      TIMESTAMP WITHOUT TIME ZONE NOT NULL,
  updated_at      TIMESTAMP WITHOUT TIME ZONE NOT NULL
);

CREATE TABLE IF NOT EXISTS iuran_pembayaran (
  id             VARCHAR(36) PRIMARY KEY,
  iuran_id       VARCHAR(36) NOT NULL,
  tipe_pembayar  TEXT CHECK (tipe_pembayar IN ('santri','umum')) NOT NULL,
  santri_id      VARCHAR(36) NULL,
  nama_pembayar  VARCHAR(150) NOT NULL,
  periode_bulan  CHAR(7) NULL,
  periode_tahun  SMALLINT NULL,
  nominal        BIGINT NOT NULL,
  tanggal_bayar  DATE NOT NULL,
  metode         TEXT CHECK (metode IN ('Tunai','Transfer','Lainnya')) NOT NULL DEFAULT 'Tunai',
  keterangan     TEXT NULL,
  kas_id         VARCHAR(36) NULL,
  created_at     TIMESTAMP WITHOUT TIME ZONE NOT NULL,
  created_by     VARCHAR(36) NULL,
  FOREIGN KEY (iuran_id) REFERENCES master_iuran(id) ON DELETE RESTRICT,
  FOREIGN KEY (santri_id) REFERENCES santri(id) ON DELETE SET NULL,
  FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS iuran_tambahan (
  id      VARCHAR(36) PRIMARY KEY,
  nama    VARCHAR(150) NOT NULL UNIQUE,
  tipe    TEXT CHECK (tipe IN ('Syahriyah','Kilatan','Keduanya')) NOT NULL,
  nominal BIGINT NOT NULL
);

CREATE TABLE IF NOT EXISTS kuitansi_counter (
  tahun         SMALLINT PRIMARY KEY,
  nilai_counter BIGINT NOT NULL DEFAULT 0,
  updated_at    TIMESTAMP WITHOUT TIME ZONE NOT NULL
);

CREATE TABLE IF NOT EXISTS pengaturan (
  kunci      VARCHAR(50) PRIMARY KEY,
  nilai      JSONB NOT NULL,
  updated_at TIMESTAMP WITHOUT TIME ZONE NOT NULL,
  updated_by VARCHAR(36) NULL,
  FOREIGN KEY (updated_by) REFERENCES users(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS arsip_tarif (
  id               VARCHAR(36) PRIMARY KEY,
  periode_mulai    CHAR(7) NOT NULL,
  periode_selesai  CHAR(7) NULL,
  syahriyah_mukim  BIGINT NOT NULL,
  syahriyah_nduduk BIGINT NOT NULL,
  syahriyah_kilatan BIGINT NOT NULL,
  event_kilatan    BIGINT NOT NULL,
  status           TEXT CHECK (status IN ('Aktif','Diarsipkan','Dijadwalkan')) NOT NULL,
  diarsipkan_pada  TIMESTAMP WITHOUT TIME ZONE NOT NULL,
  created_by       VARCHAR(36) NULL,
  FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS print_log (
  id           VARCHAR(36) PRIMARY KEY,
  transaksi_id VARCHAR(50) NOT NULL,
  type         TEXT CHECK (type IN ('HVS','Thermal','PDF')) NOT NULL,
  printed_at   TIMESTAMP WITHOUT TIME ZONE NOT NULL,
  printed_by   VARCHAR(36) NULL,
  FOREIGN KEY (printed_by) REFERENCES users(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS activity_log (
  id          VARCHAR(36) PRIMARY KEY,
  waktu       TIMESTAMP WITHOUT TIME ZONE NOT NULL,
  modul       TEXT CHECK (modul IN ('Santri','Pendaftaran','Syahriyah','Kilatan','Iuran','Kas','Pengaturan','Sistem')) NOT NULL,
  aksi        TEXT CHECK (aksi IN ('Tambah','Ubah','Hapus','Impor','Pembayaran','Pembatalan','Restore','Login')) NOT NULL,
  deskripsi   VARCHAR(500) NOT NULL,
  ref_id      VARCHAR(36) NULL,
  user_id     VARCHAR(36) NULL,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

CREATE INDEX IF NOT EXISTS idx_sessions_expired ON sessions (expires_at);
CREATE INDEX IF NOT EXISTS idx_santri_nama ON santri (nama);
CREATE INDEX IF NOT EXISTS idx_santri_status ON santri (status);
CREATE INDEX IF NOT EXISTS idx_periode_santri ON santri_periode_nonaktif (santri_id, mulai);
CREATE INDEX IF NOT EXISTS idx_syahriyah_tahun ON syahriyah_bulan (tahun);
CREATE INDEX IF NOT EXISTS idx_keringanan_santri ON keringanan_syahriyah (santri_id, tahun);
CREATE INDEX IF NOT EXISTS idx_trx_syahriyah_santri ON transaksi_syahriyah (santri_id);
CREATE INDEX IF NOT EXISTS idx_trx_syahriyah_tanggal ON transaksi_syahriyah (tanggal_bayar);
CREATE INDEX IF NOT EXISTS idx_kilatan_tahun ON kilatan_bulan (tahun);
CREATE INDEX IF NOT EXISTS idx_trx_kilatan_santri ON transaksi_kilatan (santri_id);
CREATE INDEX IF NOT EXISTS idx_trx_kilatan_tanggal ON transaksi_kilatan (tanggal_bayar);
CREATE INDEX IF NOT EXISTS idx_kas_tanggal ON buku_kas (tanggal);
CREATE INDEX IF NOT EXISTS idx_kas_kategori ON buku_kas (kategori_nama);
CREATE INDEX IF NOT EXISTS idx_pendaftaran_status ON pendaftaran (status);
CREATE INDEX IF NOT EXISTS idx_iuran_tanggal ON iuran_pembayaran (tanggal_bayar);
CREATE INDEX IF NOT EXISTS idx_iuran_pembayar ON iuran_pembayaran (nama_pembayar);
CREATE INDEX IF NOT EXISTS idx_arsip_periode ON arsip_tarif (periode_mulai);
CREATE INDEX IF NOT EXISTS idx_print_transaksi ON print_log (transaksi_id);
CREATE INDEX IF NOT EXISTS idx_activity_waktu ON activity_log (waktu);
CREATE INDEX IF NOT EXISTS idx_activity_modul ON activity_log (modul);

-- The application accesses PostgreSQL only from the Netlify server function.
-- Keep Supabase's public REST API closed: no anon/authenticated policies are created.
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE santri ENABLE ROW LEVEL SECURITY;
ALTER TABLE santri_periode_nonaktif ENABLE ROW LEVEL SECURITY;
ALTER TABLE syahriyah_bulan ENABLE ROW LEVEL SECURITY;
ALTER TABLE keringanan_syahriyah ENABLE ROW LEVEL SECURITY;
ALTER TABLE transaksi_syahriyah ENABLE ROW LEVEL SECURITY;
ALTER TABLE kilatan_bulan ENABLE ROW LEVEL SECURITY;
ALTER TABLE transaksi_kilatan ENABLE ROW LEVEL SECURITY;
ALTER TABLE kategori_kas ENABLE ROW LEVEL SECURITY;
ALTER TABLE buku_kas ENABLE ROW LEVEL SECURITY;
ALTER TABLE pendaftaran ENABLE ROW LEVEL SECURITY;
ALTER TABLE master_iuran ENABLE ROW LEVEL SECURITY;
ALTER TABLE iuran_pembayaran ENABLE ROW LEVEL SECURITY;
ALTER TABLE iuran_tambahan ENABLE ROW LEVEL SECURITY;
ALTER TABLE kuitansi_counter ENABLE ROW LEVEL SECURITY;
ALTER TABLE pengaturan ENABLE ROW LEVEL SECURITY;
ALTER TABLE arsip_tarif ENABLE ROW LEVEL SECURITY;
ALTER TABLE print_log ENABLE ROW LEVEL SECURITY;
ALTER TABLE activity_log ENABLE ROW LEVEL SECURITY;
