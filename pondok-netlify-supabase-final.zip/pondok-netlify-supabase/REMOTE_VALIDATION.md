# Validasi jarak jauh — Pondok Netlify + Supabase

Tanggal pembaruan: 27 November 2026

## Yang sudah berhasil

- `npm run preflight:static`: 9/9 pemeriksaan lulus (127 file TypeScript/TSX, 20 tabel unik, RLS 20/20, routing Netlify, adapter Functions, API mode, dependency `pg`).
- `npm run test:pg-adapter`: 6/6 tes terisolasi lulus.
- Project Supabase `pondok-alhidayah` aktif; 20 tabel, seluruhnya RLS aktif, dan migration untuk 16 index foreign key sudah diterapkan.
- Pemeriksaan menemukan dua kolom periode pembayaran iuran belum ada di database. Keduanya telah ditambahkan dan diverifikasi.
- Pengamanan pembuatan Super Admin awal ditambahkan: production membutuhkan `INITIAL_SETUP_SECRET` minimal 32 karakter, disimpan hanya di Netlify server environment.

## Yang belum berhasil dijalankan

- `npm install --no-audit --no-fund` timeout pada lingkungan kerja; belum tersedia `node_modules` untuk build penuh.
- Build Vite, bundling Netlify Functions, typecheck, seluruh unit test aplikasi, dan E2E belum tervalidasi.
- GitHub repo terhubung dengan izin baca saja (`pull: true`, `push: false`). Branch `main` belum berisi workflow migrasi ini; Actions melaporkan belum ada workflow run.
- Netlify site belum dibuat/deploy. Kredensial database dan secret belum disimpan di Netlify.
- Belum ada tes end-to-end API, login/setup, iframe Blogspot Android, pembayaran, pembatalan, atau kuitansi terhadap PostgreSQL.

## Jalur verifikasi

1. Masukkan isi paket ini ke branch deploy GitHub (perlu izin push/write; koneksi GitHub saat ini hanya baca) atau gunakan unggah manual.
2. Pastikan GitHub Actions menjalankan `.github/workflows/verify.yml`, lalu perbaiki semua kegagalan berdasarkan log aktual.
3. Hubungkan repo ke Netlify. Set `DATABASE_URL` dari Supabase Shared Pooler transaction mode port 6543, `NODE_ENV=production`, `SESSION_SECRET`, `INITIAL_SETUP_SECRET`, dan `CORS_ORIGINS` sebagai server-side Environment Variables. Jangan memakai `VITE_*` untuk rahasia.
4. Deploy staging, verifikasi `/health`, setup/login/logout, lalu coba iframe Blogspot pada Android.
5. Uji transaksi syahriyah, kilatan, iuran, kas, kuitansi, pembatalan, dan konkurensi sebelum mengizinkan penggunaan operasional.

**Jangan menganggap paket siap operasional hanya karena database schema berhasil diterapkan atau preflight lokal hijau.**
