import serverless from 'serverless-http';
import { createApp } from '../../server/src/app';

// Express API mounted at /.netlify/functions/api; frontend should call /api/* via redirect.
const app = createApp();
export const handler = serverless(app, { basePath: '/.netlify/functions/api' });
