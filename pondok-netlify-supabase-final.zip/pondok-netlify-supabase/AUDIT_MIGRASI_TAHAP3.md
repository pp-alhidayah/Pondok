# Audit migrasi tahap 3 — Pondok / Netlify + Supabase

Tanggal: 26 November 2026

## Perubahan tambahan pada salinan kerja

1. **Konsistensi pembayaran ketika request bersamaan**
   - Pembayaran syahriyah mengunci baris `syahriyah_bulan` dengan `FOR UPDATE` sebelum memeriksa sisa kewajiban.
   - Pembayaran kilatan mengunci baris `kilatan_bulan` dengan `FOR UPDATE` sebelum memeriksa sisa kewajiban.
   - Baris kewajiban dikunci dalam urutan tahun/bulan/event yang konsisten untuk mengurangi deadlock.
   - Pembatalan mengunci baris transaksi dan baris matriks sebelum mengembalikan saldo kewajiban.
   - Ini mengurangi risiko dua request bersamaan membaca sisa yang sama lalu mencatat pembayaran melebihi kewajiban. Tetap perlu integration test di PostgreSQL nyata.

2. **Keamanan Supabase**
   - RLS diaktifkan pada semua 20 tabel aplikasi.
   - Tidak dibuat policy untuk `anon` atau `authenticated`; browser tidak mengakses tabel Supabase secara langsung.
   - Backend Netlify tetap memakai koneksi database server-side.

3. **Migrator schema**
   - Migrator tidak lagi memecah file SQL menggunakan karakter `;` karena semicolon bisa muncul dalam komentar/string.
   - Seluruh script schema dikirim sebagai satu batch SQL dalam transaksi.

4. **Pemeriksaan Supabase setelah schema diterapkan**
   - Ditambahkan `scripts/verify-supabase.sql` untuk memeriksa jumlah tabel, RLS, constraint utama, dan tabel-tabel yang seharusnya masih kosong.
   - Ditambahkan `SUPABASE_PREFLIGHT.md` dengan urutan aman.

## Pemeriksaan yang berhasil dilakukan

- TypeScript transpile/syntax check: 129 file, 0 diagnostic sintaks.
- Struktur schema statis: 20 tabel ditemukan.
- Audit referensi tabel SQL backend: seluruh 20 nama tabel yang dirujuk cocok dengan tabel di schema; tidak ditemukan tabel yang hilang dari schema.
- RLS statis: 20 dari 20 tabel memiliki perintah `ENABLE ROW LEVEL SECURITY`.
- `netlify.toml` dan alur routing sudah ditinjau secara statis.

## Pemeriksaan yang belum bisa dilakukan

- `npm install --ignore-scripts --no-audit --no-fund --prefer-offline` timeout setelah 120 detik karena akses registry npm tidak tersedia/stabil di lingkungan ini.
- Karena dependency tidak terpasang, build Vite, typecheck penuh, unit test yang membutuhkan `tsx`, dan Netlify Functions bundling belum bisa dijalankan.
- SQL belum dieksekusi pada Supabase pengguna; belum ada PostgreSQL staging yang bisa diuji.
- Belum dilakukan test browser Android terhadap iframe dan bearer session.
- Belum ada test integrasi pembayaran, pembatalan, kas, kuitansi, serta konkurensi terhadap database nyata.

## Keputusan status

**Tahap 3: persiapan kode dan pengamanan tambahan. Belum siap deploy operasional.**

Jangan jalankan schema ke Supabase dan jangan deploy ke situs publik sebelum build + database integration test berhasil. Jangan kirim password DB, `DATABASE_URL`, `SESSION_SECRET`, atau service-role key melalui chat.
