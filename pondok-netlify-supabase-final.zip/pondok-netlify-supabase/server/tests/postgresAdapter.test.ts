import test from 'node:test';
import assert from 'node:assert/strict';
import { toPostgresSql } from '../src/db';

test('translates MySQL placeholders and quoted identifiers to PostgreSQL', () => {
  assert.equal(toPostgresSql('SELECT * FROM `santri` WHERE id = ? AND nama LIKE ?'), 'SELECT * FROM "santri" WHERE id = $1 AND nama LIKE $2');
});
test('translates YEAR and MONTH date helpers to PostgreSQL EXTRACT', () => {
  assert.equal(toPostgresSql('SELECT YEAR(tanggal), MONTH(tanggal) FROM buku_kas WHERE YEAR(tanggal) = ?'), 'SELECT EXTRACT(YEAR FROM tanggal), EXTRACT(MONTH FROM tanggal) FROM buku_kas WHERE EXTRACT(YEAR FROM tanggal) = $1');
});

test('does not rewrite question marks inside SQL string literals or comments', () => {
  assert.equal(toPostgresSql("SELECT '?' AS literal, col = ? -- ignore ?\nFROM t WHERE name = '?' AND id = ?"), "SELECT '?' AS literal, col = $1 -- ignore ?\nFROM t WHERE name = '?' AND id = $2");
});

test('keeps PostgreSQL row-lock clauses intact while converting placeholders', () => {
  assert.equal(
    toPostgresSql('SELECT nominal_tagihan FROM syahriyah_bulan WHERE santri_id = ? FOR UPDATE'),
    'SELECT nominal_tagihan FROM syahriyah_bulan WHERE santri_id = $1 FOR UPDATE'
  );
});
test('rewrites YEAR and MONTH only when they are SQL functions, not literals or comments', () => {
  assert.equal(
    toPostgresSql("SELECT 'YEAR(tanggal)' AS label, YEAR(tanggal) AS tahun -- MONTH(tanggal)\nFROM buku_kas"),
    "SELECT 'YEAR(tanggal)' AS label, EXTRACT(YEAR FROM tanggal) AS tahun -- MONTH(tanggal)\nFROM buku_kas"
  );
});
test('handles nested parentheses inside date functions', () => {
  assert.equal(
    toPostgresSql('SELECT YEAR(COALESCE(tanggal, NOW())) FROM buku_kas'),
    'SELECT EXTRACT(YEAR FROM COALESCE(tanggal, NOW())) FROM buku_kas'
  );
});
