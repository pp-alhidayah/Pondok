import assert from 'node:assert/strict';
import test from 'node:test';
import { matchesSetupSecret } from '../src/setupSecurity';

test('initial setup token accepts only an exact non-empty secret', () => {
  const secret = 'a'.repeat(64);
  assert.equal(matchesSetupSecret(secret, secret), true);
  assert.equal(matchesSetupSecret(secret, 'b'.repeat(64)), false);
  assert.equal(matchesSetupSecret(secret, `${secret}x`), false);
  assert.equal(matchesSetupSecret('', secret), false);
  assert.equal(matchesSetupSecret(secret, ''), false);
});
