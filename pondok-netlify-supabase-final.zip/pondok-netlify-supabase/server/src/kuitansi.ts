import { badRequest } from './errors';
import type { DBConnection } from './db';

/** Atomic PostgreSQL upsert prevents duplicate receipt numbers under concurrency. */
export async function nextNomorKuitansi(conn: DBConnection, tahun: number): Promise<string> {
  const [rows] = await conn.query(
    `INSERT INTO kuitansi_counter (tahun, nilai_counter, updated_at)
     VALUES (?, 1, NOW())
     ON CONFLICT (tahun) DO UPDATE
       SET nilai_counter = kuitansi_counter.nilai_counter + 1, updated_at = NOW()
     RETURNING nilai_counter`,
    [tahun]
  );
  const next = Number(rows[0]?.nilai_counter);
  if (!Number.isInteger(next) || next < 1) throw badRequest('Counter kuitansi tidak ditemukan');
  return `AH/${tahun}/${String(next).padStart(3, '0')}`;
}

export function tahunDariTanggal(tanggal: string): number {
  const year = Number(tanggal.slice(0, 4));
  if (!Number.isInteger(year) || year < 2000) throw badRequest('Tahun tanggal bayar tidak valid');
  return year;
}

export function pastikanUnikKuitansi(nomor: string): void {
  if (!/^AH\/\d{4}\/\d{3,}$/.test(nomor)) throw badRequest('Format nomor kuitansi tidak valid');
}
