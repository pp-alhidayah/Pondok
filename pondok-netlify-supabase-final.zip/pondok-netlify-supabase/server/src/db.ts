import { Pool, type PoolClient, type QueryResultRow } from 'pg';
import { isProduction } from './config';

/** PostgreSQL adapter that preserves the small mysql2-shaped interface used by existing routes. */
const connectionString = process.env.DATABASE_URL;
if (isProduction && !connectionString) throw new Error('DATABASE_URL wajib diatur di Netlify Environment Variables');

export const pool = new Pool({
  connectionString,
  host: connectionString ? undefined : process.env.PGHOST,
  port: connectionString ? undefined : Number(process.env.PGPORT || 5432),
  user: connectionString ? undefined : process.env.PGUSER,
  password: connectionString ? undefined : process.env.PGPASSWORD,
  database: connectionString ? undefined : process.env.PGDATABASE,
  // Keep TLS certificate verification enabled for Supabase connections.
  ssl: isProduction ? { rejectUnauthorized: true } : undefined,
  max: Number(process.env.PG_POOL_MAX || 5),
  idleTimeoutMillis: 10_000,
  connectionTimeoutMillis: 10_000,
});

export type Rows = QueryResultRow[];
export interface ExecuteResult { affectedRows: number; rowCount: number; rows: Rows }
export interface DBConnection {
  query(sql: string, params?: unknown[]): Promise<[Rows]>;
  execute(sql: string, params?: unknown[]): Promise<ExecuteResult>;
  beginTransaction(): Promise<void>;
  commit(): Promise<void>;
  rollback(): Promise<void>;
  release(): void;
}

/** Translate the MySQL syntax used by this project without rewriting quoted values. */
export function toPostgresSql(source: string): string {
  let sql = '';
  let index = 0;
  let state: 'normal' | 'single' | 'double' | 'backtick' | 'line' | 'block' = 'normal';
  // Rewrite YEAR()/MONTH() only in normal SQL, never inside literals/comments.

  for (let i = 0; i < source.length; i += 1) {
    const ch = source[i];
    const next = source[i + 1];
    if (state === 'normal') {
      const dateFn = source.slice(i).match(/^(YEAR|MONTH)\s*\(/i);
      if (dateFn) {
        const kind = dateFn[1].toUpperCase() === 'YEAR' ? 'extract-year' : 'extract-month';
        sql += `EXTRACT(${kind === 'extract-year' ? 'YEAR' : 'MONTH'} FROM `;
        i += dateFn[0].length - 1;
      } else if (ch === "'") { state = 'single'; sql += ch; }
      else if (ch === '"') { state = 'double'; sql += ch; }
      else if (ch === '`') { state = 'backtick'; sql += '"'; }
      else if (ch === '-' && next === '-') { state = 'line'; sql += ch + next; i += 1; }
      else if (ch === '/' && next === '*') { state = 'block'; sql += ch + next; i += 1; }
      else if (ch === '?') { index += 1; sql += `$${index}`; }
      else sql += ch;
    } else if (state === 'single') {
      sql += ch;
      if (ch === "'" && next === "'") { sql += next; i += 1; }
      else if (ch === "'") state = 'normal';
      else if (ch === '\\' && next) { sql += next; i += 1; }
    } else if (state === 'double') {
      sql += ch;
      if (ch === '"' && next === '"') { sql += next; i += 1; }
      else if (ch === '"') state = 'normal';
    } else if (state === 'backtick') {
      if (ch === '`' && next === '`') { sql += '``'; i += 1; }
      else if (ch === '`') { state = 'normal'; sql += '"'; }
      else sql += ch;
    } else if (state === 'line') {
      sql += ch;
      if (ch === '\n') state = 'normal';
    } else {
      sql += ch;
      if (ch === '*' && next === '/') { sql += next; i += 1; state = 'normal'; }
    }
  }
  return sql;
}

async function run(client: Pick<PoolClient, 'query'>, sql: string, params: unknown[] = []) {
  return client.query(toPostgresSql(sql), params);
}

export async function query<T extends Rows = Rows>(sql: string, params: unknown[] = []): Promise<T> {
  const result = await run(pool, sql, params);
  return result.rows as T;
}

export async function execute(sql: string, params: unknown[] = []): Promise<ExecuteResult> {
  const result = await run(pool, sql, params);
  return { affectedRows: result.rowCount ?? 0, rowCount: result.rowCount ?? 0, rows: result.rows as Rows };
}

function wrapClient(client: PoolClient): DBConnection {
  return {
    async query(sql, params = []) { const result = await run(client, sql, params); return [result.rows as Rows]; },
    async execute(sql, params = []) { const result = await run(client, sql, params); return { affectedRows: result.rowCount ?? 0, rowCount: result.rowCount ?? 0, rows: result.rows as Rows }; },
    async beginTransaction() { await client.query('BEGIN'); },
    async commit() { await client.query('COMMIT'); },
    async rollback() { await client.query('ROLLBACK'); },
    release() { client.release(); },
  };
}

export async function withTransaction<T>(work: (conn: DBConnection) => Promise<T>): Promise<T> {
  const client = await pool.connect();
  const conn = wrapClient(client);
  try {
    await conn.beginTransaction();
    const result = await work(conn);
    await conn.commit();
    return result;
  } catch (error) {
    await conn.rollback().catch(() => undefined);
    throw error;
  } finally {
    conn.release();
  }
}

export async function checkDatabase(): Promise<void> { await query('SELECT 1 AS ok'); }
