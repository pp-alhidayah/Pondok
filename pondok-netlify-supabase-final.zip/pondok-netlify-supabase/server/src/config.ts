import dotenv from 'dotenv';
dotenv.config();
const numberFrom = (value: string | undefined, fallback: number): number => { const parsed = Number(value); return Number.isFinite(parsed) ? parsed : fallback; };
export const config = {
  port: numberFrom(process.env.PORT, 3001),
  corsOrigins: (process.env.CORS_ORIGINS || process.env.CORS_ORIGIN || 'http://localhost:3000').split(',').map((origin) => origin.trim()).filter(Boolean),
  sessionSecret: process.env.SESSION_SECRET || 'dev-only-session-secret',
  initialSetupSecret: process.env.INITIAL_SETUP_SECRET || '',
  sessionTtlHours: numberFrom(process.env.SESSION_TTL_HOURS, 12),
};
export const isProduction = process.env.NODE_ENV === 'production';
if (isProduction && config.sessionSecret === 'dev-only-session-secret') throw new Error('SESSION_SECRET wajib diganti di produksi');
if (isProduction && config.initialSetupSecret.length < 32) throw new Error('INITIAL_SETUP_SECRET wajib diatur minimal 32 karakter di Netlify');
