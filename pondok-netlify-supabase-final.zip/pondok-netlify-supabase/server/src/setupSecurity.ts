import { timingSafeEqual } from 'node:crypto';

/** Compare one-time setup secrets without leaking prefix-match timing. */
export function matchesSetupSecret(expected: string, supplied: string): boolean {
  if (!expected || !supplied) return false;
  const expectedBuffer = Buffer.from(expected, 'utf8');
  const suppliedBuffer = Buffer.from(supplied, 'utf8');
  if (expectedBuffer.length !== suppliedBuffer.length) return false;
  return timingSafeEqual(expectedBuffer, suppliedBuffer);
}
