import { readFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { pool } from './db';

async function migrate(): Promise<void> {
  const schemaPath = fileURLToPath(new URL('../../schema-supabase.sql', import.meta.url));
  const sql = await readFile(schemaPath, 'utf8');
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    // Send the complete script as one simple-query batch. Splitting on semicolons
    // is unsafe because SQL comments and string literals may contain semicolons.
    await client.query(sql);
    await client.query('COMMIT');
    console.log('Schema Supabase berhasil diterapkan.');
  } catch (error) {
    await client.query('ROLLBACK').catch(() => undefined);
    throw error;
  } finally {
    client.release();
    await pool.end();
  }
}

migrate().catch((error) => {
  console.error('Migrasi gagal:', error);
  process.exit(1);
});
