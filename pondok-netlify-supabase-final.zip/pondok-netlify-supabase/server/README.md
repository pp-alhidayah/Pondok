# Backend API — Sistem Informasi Pondok Al Hidayah

Backend Express memakai PostgreSQL (`pg`). Untuk produksi, Express dijalankan melalui Netlify Functions; untuk pengembangan lokal dapat dijalankan pada port 3001.

## Prasyarat

- Node.js 20+
- PostgreSQL 15+ (Supabase PostgreSQL dapat digunakan)
- Isi `.env` berdasarkan `.env.example`; gunakan `DATABASE_URL` atau variabel `PGHOST`/`PGPORT`/`PGUSER`/`PGPASSWORD`/`PGDATABASE`.
- `SESSION_SECRET` harus berupa nilai acak panjang dan hanya disimpan di server.

## Menjalankan lokal

```bash
npm install --legacy-peer-deps
npm run db:migrate      # menerapkan schema-supabase.sql
npm run server          # API di http://localhost:3001
# atau: npm run dev:server
```

## Alur awal (database kosong)

1. `POST /api/auth/setup` — membuat Super Admin pertama (hanya dapat berhasil sekali).
2. `POST /api/auth/login` — mengembalikan bearer session acak dan `csrfToken`.
3. Frontend menyimpan bearer session di `sessionStorage` dalam iframe dan mengirimkannya sebagai `Authorization: Bearer ...`.
4. Sertakan `x-csrf-token` pada semua mutation setelah login.

## Netlify + Blogspot

- `netlify/functions/api.ts` membungkus Express menggunakan `serverless-http`.
- `netlify.toml` mengarahkan `/api/*` ke function dan menetapkan `VITE_API_MODE=api`.
- CSP mengizinkan iframe dari `https://alhidayah-tertek.blogspot.com`.
- Sesi tidak bergantung pada third-party cookies; tetap wajib diuji di browser Android/iOS setelah deploy staging.

## Endpoint utama

| Prefix | Isi |
|---|---|
| `/api/auth/*` | setup, login, me, logout |
| `/api/pembayaran/*` | pembayaran syahriyah/kilatan/iuran, pembatalan, riwayat |
| `/api/master/*` | santri, pendaftaran, kas, master iuran, pengaturan, users |
| `/api/laporan/:jenis` | laporan keuangan, santri, pendaftaran, syahriyah, iuran, kilatan |
| `/api/aktivitas`, `/api/print-log` | audit trail dan log cetak |
| `/api/backup`, `/api/restore` | backup/restore (Super Admin) |
| `/health` | health check database |

## Catatan penting

- Pembayaran, kas, matriks kewajiban, dan kuitansi harus diuji sebagai satu transaksi atomik pada PostgreSQL staging.
- Counter kuitansi memakai upsert PostgreSQL atomik.
- Pembatalan pembayaran tidak mengembalikan nomor kuitansi.
- `pemilik` bersifat read-only; middleware menolak mutation dengan 403.
- Password disimpan sebagai hash bcrypt cost 12; `password_hash` tidak dikirim ke client.

Build, test integrasi, dan smoke test PostgreSQL **belum dinyatakan lulus**. Jangan gunakan database operasional sebelum seluruh pengujian tersebut selesai.
