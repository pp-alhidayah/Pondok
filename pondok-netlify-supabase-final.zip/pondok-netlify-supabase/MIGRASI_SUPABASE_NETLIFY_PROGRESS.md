# Progres port backend PostgreSQL / Netlify

## Perubahan kode yang sudah dibuat pada salinan kerja
- Driver database backend dialihkan dari `mysql2` ke `pg` (PostgreSQL).
- Adapter transaksi mempertahankan antarmuka query/execute yang dipakai route lama.
- Placeholder `?`, identifier backtick, serta fungsi `YEAR()` dan `MONTH()` diterjemahkan ke sintaks PostgreSQL.
- Nomor kuitansi diubah menjadi `INSERT ... ON CONFLICT ... RETURNING` yang atomik untuk konkurensi.
- Upsert pengaturan diubah ke `ON CONFLICT` PostgreSQL.
- Migrator lokal diarahkan ke file `schema-supabase.sql`.
- Netlify Function Express adapter dan redirect `/api/*` disiapkan.
- Header `frame-ancestors` membatasi embedding ke Blogspot Al-Hidayah.
- Tes unit awal untuk penerjemah SQL ditambahkan.
- Pembayaran syahriyah/kilatan kini mengunci baris kewajiban (`FOR UPDATE`) sebelum memvalidasi sisa pembayaran; pembatalan mengunci transaksi dan matriks terkait agar request bersamaan tidak mengubah saldo secara balapan.
- Migrasi schema mengirim satu batch SQL utuh (tidak memecah dengan `;`, karena komentar SQL dapat mengandung titik koma).
- RLS diaktifkan pada seluruh 20 tabel aplikasi; tidak ada policy publik. Backend mengakses DB secara server-side.

## Status deploy: belum siap operasional — jangan gunakan untuk transaksi nyata
1. **Autentikasi iframe:** sudah menggunakan bearer session acak 256-bit di header Authorization dan `sessionStorage` iframe; token CSRF tetap wajib untuk mutation. Belum diuji di browser Android/iOS.
2. Dependensi baru (`pg`, `serverless-http`) belum berhasil di-resolve karena proses npm install timeout di lingkungan kerja ini. `package-lock.json` sengaja tidak disertakan agar tidak menyimpan lockfile lama yang tidak cocok.
3. Schema sudah berhasil diterapkan langsung ke project Supabase `pondok-alhidayah`: 20 tabel dibuat dan RLS aktif pada semua tabel. Kolom `periode_bulan` serta `periode_tahun` pada `iuran_pembayaran` sempat tertinggal dari migrasi awal, lalu ditambahkan melalui migration terpisah dan diverifikasi. Belum ada pengujian integrasi transaksi/pembayaran/kuitansi melalui API.
4. Fungsi `YEAR/MONTH` dan semua SQL dinamis perlu verifikasi dengan PostgreSQL nyata. Adapter ini hanya mencakup pola yang ditemukan pada audit awal.
5. CORS harus diisi dengan origin Netlify yang benar setelah URL situs diketahui. CSP sudah membatasi frame ancestor Blogspot.
6. Belum ada smoke test Netlify Function atau validasi build TypeScript.

## Environment variables Netlify (server-side only)
`DATABASE_URL` (Shared Pooler Supavisor transaction mode/port 6543), `NODE_ENV=production`, `CORS_ORIGINS` (URL Netlify app), `SESSION_SECRET`, `INITIAL_SETUP_SECRET` (minimal 32 karakter), `SESSION_TTL_HOURS`, `PG_POOL_MAX`.

Jangan pernah menaruh password database atau `service_role` di variabel `VITE_*`, frontend, Blogger, atau GitHub.
