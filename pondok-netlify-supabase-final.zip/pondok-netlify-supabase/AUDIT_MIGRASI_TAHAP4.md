# Audit migrasi tahap 4 — Pondok / Netlify + Supabase

Tanggal: 26 November 2026

## Perubahan pada salinan kerja

1. Penerjemah SQL PostgreSQL kini mengubah `YEAR()` dan `MONTH()` hanya ketika berada di konteks SQL normal. Teks serupa di string literal dan komentar tidak disentuh.
2. Ditambahkan regresi test untuk fungsi tanggal di string/komentar dan fungsi tanggal dengan ekspresi bersarang.
3. Koneksi produksi ke PostgreSQL mengaktifkan verifikasi sertifikat TLS (`rejectUnauthorized: true`), bukan menerima sertifikat tanpa verifikasi.
4. Ditambahkan `npm run preflight:static` untuk memeriksa sintaks TypeScript/TSX, jumlah tabel schema, cakupan RLS, konfigurasi routing Netlify, adapter function, dan mode API produksi.

## Pemeriksaan yang berhasil

- Static preflight: 7/7 pemeriksaan lulus.
- Parser TypeScript: 126 file TypeScript/TSX, 0 kesalahan sintaks.
- Schema: 20 tabel unik; 20/20 tabel memiliki `ENABLE ROW LEVEL SECURITY`.
- File test adapter PostgreSQL yang ada di proyek dijalankan: 6/6 lulus. Untuk pengujian ini modul koneksi `pg` dan `dotenv` dibuat stub; tidak ada koneksi atau transaksi database nyata.
- Pemeriksaan penerjemah SQL: placeholder, identifier backtick, komentar, string literal, `YEAR()`/`MONTH()`, dan ekspresi bersarang lulus.
- Netlify redirect, function adapter, `VITE_API_MODE=api`, dan dependency `pg` terdeteksi.

## Belum bisa dinyatakan lulus

- `npm install` dicoba ulang tetapi timeout karena registry npm tidak dapat dijangkau dari lingkungan kerja. Karena itu `npm run build`, `npm run lint`, unit test penuh, dan bundling Netlify belum dijalankan.
- Belum ada koneksi staging ke project Supabase; schema dan transaksi belum dieksekusi pada PostgreSQL nyata.
- Belum diuji browser Android/desktop untuk login bearer dalam iframe Blogspot.
- Belum ada URL Netlify produksi, jadi environment variables dan iframe embed belum dapat diverifikasi end-to-end.

## Status

**Tahap 4: pemeriksaan statis dan hardening tambahan selesai; belum siap deploy operasional.** Jangan jalankan schema di Supabase atau gunakan aplikasi untuk transaksi pondok sampai build dan integration test PostgreSQL berhasil.
