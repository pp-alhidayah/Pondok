# Pemeriksaan Supabase sebelum deploy

Status dokumen: disiapkan, belum dijalankan terhadap project Supabase pengguna.

## Urutan aman
1. Pastikan project Supabase yang dipakai memang `pondok-alhidayah` dan masih kosong.
2. Buka SQL Editor, jalankan `schema-supabase.sql` satu kali.
3. Jalankan `scripts/verify-supabase.sql`.
4. Hasil pemeriksaan harus menunjukkan `table_count = 20` dan `rls_enabled_count = 20`.
5. Pastikan query jumlah baris menunjukkan nol untuk semua tabel yang diperiksa.
6. Jangan membuat user demo manual di SQL. Akun Super Admin pertama dibuat melalui layar setup aplikasi setelah staging berjalan.

## Keamanan
- Backend Netlify menggunakan koneksi PostgreSQL server-side melalui `DATABASE_URL`.
- Jangan menaruh `DATABASE_URL`, password database, `SESSION_SECRET`, atau Supabase `service_role` key di `VITE_*`, HTML Blogger, atau kode frontend.
- RLS diaktifkan untuk semua tabel aplikasi dan tidak dibuatkan policy publik. Aplikasi tidak menggunakan Supabase anon key dari browser.
- `DATABASE_URL` hanya disimpan pada Netlify Environment Variables. Gunakan connection string Supabase yang direkomendasikan untuk serverless/pooling, dengan SSL.
- Setelah staging teruji, ganti `SESSION_SECRET` dengan nilai acak panjang (minimal 32 byte), dan set `NODE_ENV=production`.

## Belum boleh dilakukan
Jangan mengaktifkan aplikasi untuk transaksi pondok sampai build, smoke test, dan uji alur transaksi terhadap database staging berhasil.
